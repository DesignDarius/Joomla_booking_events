DROP TABLE IF EXISTS `#__book_event_`;
